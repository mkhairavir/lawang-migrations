#!/bin/sh
export SERVER_PORT=8889
export SAP_MHOST=sepappvip.sig.id
export SAP_HOST=sepappvip.sig.id
export SAP_PORT=3621
export SAP_GROUP=SAPRFC4
export SAP_USER=RFCSDONLINE3
export SAP_PASSWORD=password
export SAP_CLIENT=210
export SAP_SYSNR=20
export SAP_ROUTER=
export SAP_LANG=en
export SAP_SYSTEMID=SEP

java -XX:+HeapDumpOnOutOfMemoryError -server -Xms128M -Xmx1000M -Duser.timezone="Asia/Jakarta" -Dprogram.name=SAPADAPTER -jar sap-env.jar > logs/backend-log 2>&1 &

echo $! > logs/backend.pid